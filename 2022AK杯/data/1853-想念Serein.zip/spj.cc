#include "testlib.h"
using namespace std;
signed main(int argc, char *argv[])
{
    registerTestlibCmd(argc, argv);
    string si = inf.readString();
    string sa = ouf.readLine();
    string sb = ouf.readLine();
    string sc = ouf.readLine();
    string sr = ans.readString();
    if (sa == sb && sb == sc && sa == "I Miss Serein")
    {
        quitf(_ok, "I really miss Serein");
    }
    else
    {
        quitf(_wa, "yours:[%s][%s][%s]", sa.c_str(), sb.c_str(), sc.c_str());
    }
}