#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;
int main(int argc, char *argv[])
{
    registerTestlibCmd(argc, argv);
    string pans = ouf.readString();
    string jans = ans.readString();
    jans = jans.substr(0, jans.length() - 1);
    if (jans == pans)
    {
        quitf(_ok, "The answer is correct.");
    }
    quitf(_wa, "The answer is not correct.");
}
