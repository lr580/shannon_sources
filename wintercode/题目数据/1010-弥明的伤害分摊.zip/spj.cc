// #include <bits/stdc++.h>
#define oj
// #undef oj
#ifdef oj
#include "testlib.h"
#endif
typedef long long ll;
typedef double db;
#define re register
using namespace std;
#define sc(x) scanf("%lld", &x)
#define rep(i, a, b) for (re ll i = a; i < b; ++i)
#define repe(i, a, b) for (re ll i = a; i <= b; ++i)
#define red(i, a, b) for (re ll i = a; i > b; --i)
#define rede(i, a, b) for (re ll i = a; i >= b; --i)
db a, b, c;
ll t;
signed main(int argc, char *argv[])
{
    registerTestlibCmd(argc, argv);
    for (ll i = 0; i < 4; ++i)
    {
        t = inf.readInt();
    }
    for (ll i = 0; i < t; ++i)
    {
        for (ll j = 0; j < 2; ++j)
        {
            b = ouf.readReal();
            c = ans.readReal();
            if (!doubleCompare(c, b, 1e-2))
                quitf(_wa, "WA");
        }
    }
    quitf(_ok, "AC");
}