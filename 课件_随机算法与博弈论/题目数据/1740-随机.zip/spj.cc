#include "testlib.h"
using namespace std;
signed main(int argc, char *argv[])
{
    registerTestlibCmd(argc, argv);
    string a = ouf.readString();
    // string b = ans.readString();
    // string c = inf.readString();
    quitf(_ok, "QwQ");
}